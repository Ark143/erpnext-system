// Copyright (c) 2026, Autometrik and contributors
// For license information, please see license.txt

frappe.ui.form.on("Vehicle Inspection Item", {
	refresh(frm) {
	},
});
