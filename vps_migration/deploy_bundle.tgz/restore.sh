#!/bin/bash
# Runs INSIDE the erpnext container (after postgres is up) to restore the DB,
# install the vehicle_management app, migrate, and build assets.
set -euo pipefail

cd /workspace/frappe-bench
export PATH="/workspace/frappe-bench/env/bin:$PATH" 2>/dev/null || true

echo ">> waiting for postgres"
until pg_isready -h postgres -p 5432 -U postgres; do sleep 2; done

echo ">> creating role + database"
psql -h postgres -U postgres -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='site1_local') THEN CREATE ROLE site1_local LOGIN PASSWORD 'postgres'; END IF; END \$\$;"
psql -h postgres -U postgres -c "ALTER ROLE site1_local WITH SUPERUSER;"
psql -h postgres -U postgres -tc "SELECT 1 FROM pg_database WHERE datname='site1_local'" | grep -q 1 || \
  psql -h postgres -U postgres -c "CREATE DATABASE site1_local OWNER site1_local;"

echo ">> restoring dump"
pg_restore -h postgres -U postgres -d site1_local --no-owner --no-privileges -j 4 /tmp/artifacts/site1_local.dump || \
  echo "WARN: pg_restore reported errors (may be pre-existing objects); continuing"

echo ">> ensure apps.txt + symlinks"
cd sites
ln -sfn site1.local localhost
ln -sfn site1.local erp.localhost
mkdir -p site1.local/logs logs
cd ..

echo ">> install vehicle_management app"
bench --site site1.local install-app vehicle_management --force || echo "WARN: install-app failed; will retry via migrate"

echo ">> migrate"
bench --site site1.local migrate || echo "WARN: migrate reported issues"

echo ">> build assets"
cd sites
python -c "
import frappe
frappe.init(site='site1.local', sites_path='/workspace/frappe-bench/sites')
import frappe.build as b
b.bundle(mode='production', verbose=True)
print('BUNDLE DONE')
" || echo "WARN: asset build failed"

echo ">> restore public files (logo/favicon)"
mkdir -p sites/site1.local/public
tar xzf /tmp/artifacts/site_public.tgz -C sites/site1.local/ 2>/dev/null || true

echo "RESTORE_DONE"
